<html>
    <head>

    </head>
    <body>
        document.write("hello script");
    </body>
</html>