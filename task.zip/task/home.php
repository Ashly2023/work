<?php
include("connection.php");
if(isset($_POST['submit']))
{   
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$sql = "INSERT INTO reg (name,email,phone)
     VALUES ('$name','$email','$phone')";
   mysqli_query($mysqli,$sql);
   header("Location:view.php");
 }
?> 

<!DOCTYPE html>
<html>
</title></title>
    <head>
    <style>
      h4
      {
        color:cyan;
        font-size:20px;
      }
      h1
      {
        text-align:center;
      }
ul {
  list-style-type: none; 
  margin: 0;
  padding: 0;
  overflow:hidden;   
  background-color: #dddddd;;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
</style>
</head>
<body>
 
  <h1 style="color:tan;">Web Page</h1>
      <ul>
      <li><a href="">Home</a></li>
      <li><a href="">About</a></li>
      <li><a href="">Services</a></li>
      <li><a href="">Project</a></li>
      <li><a href="">Contact Us</a></li>
      </ul>
      <img src="image/download3.jpg" width="1800px" height="500px">
        <p>Online shopping is a form of electronic commerce which allows consumers to directly buy goods or services from a seller over the Internet using a web browser or a 
          mobile app. Consumers find a product of interest by visiting the website of the retailer directly or by searching among alternative vendors using a shopping search 
          engine, which displays the same product's availability and pricing at different e-retailers. As of 2020, customers can shop online using a range of different computers 
          and devices,including desktop computers, laptops, tablet computers and smartphones.</p>
        <p>Nature, in the broadest sense, is the physical world or universe. "Nature" can refer to the phenomena of the physical world, and also to life in general.
          The study of nature is a large, if not the only, part of science.Although humans are part of nature, human activity is often understood as a separate category 
          from other natural phenomena</p>

        <h2>Form Details</h2>
          <form method="post" action=" ">   
         Name:<input type="text" name="name"><br><br>
        Eamil:<input type="text" name="email"><br><br>
        Phone:<input type="text" name="phone"><br><br>
     <input type="submit" name="submit" value="submit">
     
<footer class="footer">
<div class="container"> 
<div class="row">
</div>
</div>
</footer>
</body>    
</html>