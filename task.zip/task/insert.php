<?php
include("connection.php");
if(isset($_POST['submit']))
{   
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$sql = "INSERT INTO reg (name,email,phone)
     VALUES ('$name','$email','$phone')";
   mysqli_query($mysqli,$sql);
   header("Location:view.php");
 }
?> 
<!DOCTYPE html>
<html>
    <title></title>
    <head>
    <script type="text/javascript">
        function fun()
        {
            var letter=/^[A-Za-z]+$/;
            var no = /^\d{10}$/;
            var vemail=/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
            var uname = document.form1.uname;
            var email=document.form1.email.value;
            var phone= document.form1.phone.value;
            if(uname=="")
            {
                alert("please enter your name");
                return false;
            }
         
            if(uname.value.match(letter))
             {
             alert("only characters are allowed");
             return false;
             }
          
            if(email=="")
            {
                alert("please enter the email");
                return false;
            }
            
                if(vemail.test(email==false))
                {
                    alert("invalid email address");
                    return false;
                }
            
                if(phone=="")
            {
                alert("please enter the number");
                return false;
            }

            if(no.test(phone==false))
            {
                alert("only numbers are allowed");
                return false;
            }
        }

</script>
</head>
<body>
 <form name="form1" method="post" action="" onsubmit="return fun()">   
          <h2>Form Details</h2>
         Name:<input type="text" name="name"><br><br>
         Email:<input type="text" name="email"><br><br>
         Phone:<input type="text" name="phone"><br><br>
        <input type="submit" name="submit" value="submit">
          </form>
</body>
</html>