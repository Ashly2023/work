<html>
    <title></title>
    <head>
</head>
<body>


<form method="post" action=""> 
          <h2>Form Details</h2>
          Name:<input type ="text" name="name"><br><br>
          Email:<input type ="text" name="email"><br><br>
         Phone:<input type ="text" name="phone"><br><br>
          <input type="submit" name="submit" value="submit">
          </form>
</body>
</html>